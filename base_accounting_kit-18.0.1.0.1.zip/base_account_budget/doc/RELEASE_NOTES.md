## Module <base_account_budget>

#### 07.10.2024
#### Version 18.0.1.0.0
#### ADD
- Initial commit for Budget Management
