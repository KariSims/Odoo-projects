## Module <sale_stock_restrict>

#### 03.11.2024
#### Version 18.0.1.0.0
#### ADD
- Initial Commit for Sale Stock Restrict
