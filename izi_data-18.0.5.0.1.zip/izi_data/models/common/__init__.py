# -*- coding: utf-8 -*-
# Copyright 2022 IZI PT Solusi Usaha Mudah

from . import izi_tools
from . import izi_data_source
from . import izi_table
from . import izi_analysis
from . import db_odoo
from . import ir_attachment
from . import ir_cron
from . import izi_kpi