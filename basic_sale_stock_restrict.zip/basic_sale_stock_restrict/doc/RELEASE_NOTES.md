## Module <basic_sale_stock_restrict>

#### 25.06.2025
#### Version 18.0.1.0.0
#### ADD
- Initial Commit for Sale Stock Restrict
