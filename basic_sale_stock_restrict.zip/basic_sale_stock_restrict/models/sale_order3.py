from odoo import models, _
from odoo.exceptions import ValidationError

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    def action_confirm(self):
        """Block confirmation if any product has insufficient stock"""
        for order in self:
            error_lines = []
            for line in order.order_line:
                product = line.product_id
                if product.type == 'consu':  # Stockable products only
                    available_qty = product.free_qty
                    if line.product_uom_qty > available_qty:
                        error_lines.append(
                            _(
                                "Produit '%s': commandé %.2f mais seulement %.2f disponible."
                            ) % (product.display_name, line.product_uom_qty, available_qty)
                        )
            if error_lines:
                raise ValidationError(
                    _("Impossible de confirmer la commande en raison d’un stock insuffisant:\n\n") +
                    "\n".join(error_lines)
                )
        return super().action_confirm()
